package kelas.ruangUsaha;

public class RuangUsaha {
  
}
