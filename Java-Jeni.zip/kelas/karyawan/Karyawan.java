package kelas.karyawan;

public class Karyawan {
  
}
