package kelas.penyewa;

public class Penyewa {
  
}