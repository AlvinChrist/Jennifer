package kelas.cabang;

public class Cabang {
  
}